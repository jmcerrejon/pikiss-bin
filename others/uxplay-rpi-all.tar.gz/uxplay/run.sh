#!/bin/bash
clear
echo "
Steps
=====

1) On your iDevice, open the Control Center by swiping up from the bottom of the device screen or swiping down from the top right corner of the screen (varies by device and iOS version).
2) The UxPlay server and its client must be on the same local area network.
3) Tap the 'Screen Mirroring' or 'AirPlay' button and choose uxplay.
4) EXIT: CTRL + C

NOTES:

· I didn't get it to work streaming throught the apps (Youtube,...). I had to use the screen mirroring feature.
· More info ./uxplay or ./uxplay_aarch64 -h or visiting support site at: https://github.com/FDH2/UxPlay
"

get_xdg_session_type() {
    echo "$XDG_SESSION_TYPE"
}

run() {
    local UXPLAY_BINARY="uxplay"
    local VIDEO_SERVER="kmssink"

    if get_xdg_session_type | grep -q "wayland"; then
        VIDEO_SERVER="waylandsink"
    fi

    if [ "$(getconf LONG_BIT)" == "64" ]; then
        UXPLAY_BINARY="uxplay_aarch64"
    fi
    ./"$UXPLAY_BINARY" -p -bt709 -n uxplay -fs -nh -vs $VIDEO_SERVER
}

run
